# Your First Web Application with Spring Boot
Develop your first web application with Spring Boot in more than 25 steps
* [Installing Eclipse, Maven and Java](#installing-tools)
* [Course Overview](#course-overview)
* [About in28Minutes](#about-in28minutes)
  - [Our Beliefs](#our-beliefs)
  - [Our Approach](#our-approach)
  - [Find Us](#useful-links)
  - [Other Courses](#other-courses)

## Installing Tools
- PDF : https://github.com/in28minutes/SpringIn28Minutes/blob/master/InstallationGuide-JavaEclipseAndMaven_v2.pdf
- Video : https://www.youtube.com/playlist?list=PLBBog2r6uMCSmMVTW_QmDLyASBvovyAO3
- GIT Repository : https://github.com/in28minutes/getting-started-in-5-steps

## Course Overview

### Introduction
Developing your first Spring Boot Web Application is fun.

Spring Boot makes it easy to create stand-alone, production-grade Spring based Applications that you can “just run”. We take an opinionated view of the Spring platform and third-party libraries so you can get started with minimum fuss. Most Spring Boot applications need very little Spring configuration.

In this course, you will learn the basics developing a Basic Todo Management Application using Spring Boot with Login and Logout functionalities.

You will build the website step by step - in more than 25 steps. This course would be a perfect first step as an introduction to Java Web Application Development.

You will be using Spring (Dependency Management), Spring MVC, Spring Boot, Spring Security (Authentication and Authorization), BootStrap (Styling Pages), Maven (dependencies management), Eclipse (IDE) and Tomcat Embedded Web Server. We will help you set up each one of these.

You will learn about
- Basics of Spring Boot
- Basics of Autoconfiguration and Spring Boot Magic
- DispatcherServlet
- Basic Todo Management Application with Login/Logout
- Model, Controllers, ViewResolver and Filters
- Forms - DataBinding, Validation
- Annotation based approach - @RequestParam, @ModelAttribute, @SessionAttributes etc
- Bootstrap to style the page
- Spring Security
- Exception Handling

### Step Wise Details
- Step 01: Basic Spring Boot Web Application Setup
- Step 02: First Spring MVC Controller, @ResponseBody, @Controller
- Step 03: Demystifying some of the Spring Boot magic
- Step 04: Redirect to Login JSP - LoginController, @ResponseBody and View Resolver
- Step 05: Show userid and password on the welcome page - ModelMap and @RequestParam
- Step 06: DispatcherServlet and Spring MVC Flow
- Step 07: Your First HTML form
- Step 08: Add hard-coded validation of userid and password
- Step 09: Magic of Spring
- Step 10: Create TodoController and list-todos view. Make TodoService a @Service and inject it.
- Step 11: Architecture of Web Applications
- Step 12: Session vs Model vs Request - @SessionAttributes
- Step 13: Add new todo
- Step 14: Display Todos in a table using JSTL Tags
- Step 15: Bootstrap for Page Formatting using webjars
- Step 16: Let's delete a Todo
- Step 17: Format Add Todo Page and Adding Basic HTML5 form validation
- Step 18: Introduce JSR 349 Validations using Hibernate Validator - First Command Bean.
- Step 19: Updating a todo
- Step 20: Let's add a Target Date for Todo - Use initBinder to Handle Date Fields
- Step 21: JSP Fragments and Navigation Bar
- Step 22: Preparing for Spring Security
- Step 23: Initial Spring Security Setup
- Step 24: Refactor and add Logout Functionality using Spring Security
- Step 25: Exception Handling

---

- We do NOT interact with a Database in this Beginner’s Course.
- We will be building a traditional JSP based web application in this course. 

---

### Expectations
- You should know Java. You should understand usage of Annotations.
- You should understand the basics of Spring framework.
- You are NOT expected to have any experience with Eclipse or Maven.
- We will help you install Eclipse and get up and running with Maven.

## Let's have some fun
- What are we waiting for?
- Let's have some fun building a web application Spring Boot in 25 Steps.
- I had fun creating this course and hope you would too.
- Thanks for your interest in Our Course 
  - I hope you’re as excited as I am!  
  - If you’re ready to learn more and sign up for the course, 
  - go ahead and hit that Enroll button, 
  - or take a test drive by using the Free Preview feature.  
- See you in the course!

## Getting Started
- Eclipse - https://courses.in28minutes.com/p/eclipse-tutorial-for-beginners
- Maven - https://courses.in28minutes.com/p/maven-tutorial-for-beginners-in-5-steps
- JUnit - https://courses.in28minutes.com/p/junit-tutorial-for-beginners
- Mockito - https://courses.in28minutes.com/p/mockito-for-beginner-in-5-steps

## About in28Minutes

At in28Minutes, we ask ourselves one question everyday
> How do we create more amazing course experiences? 
> We use 80-20 Rule. We discuss 20% things used 80% of time in depth.

We are creating amazing learning experiences for learning Spring Boot with AWS, Azure, GCP, Docker, Kubernetes and Full Stack. 300,000 Learners rely on our expertise.  [Find out more.... ](https://github.com/in28minutes/learn#best-selling-courses)

![in28MinutesLearningRoadmap-July2019.png](https://github.com/in28minutes/in28Minutes-Course-Roadmap/raw/master/in28MinutesLearningRoadmap-July2019.png)
